# Medicare Assistant — Educational AI Medical Chatbot

A clean, reliable, and production-grade **Medicare AI Chatbot** built with **Python, Flask, SQLite, and Vanilla JavaScript**. Designed for academic projects, healthcare demonstrations, and viva presentations.

---

## 1. Project Overview

**Medicare Assistant** is a web-based educational medical information assistant. It provides clear, evidence-based health guidance on common symptoms, wellness practices, first aid, and red-flag warning signs.

> **Important Safety Note:** Medicare Assistant is an educational information resource, not a diagnostic platform or a licensed physician. It never claims diagnostic certainty and automatically elevates acute or life-threatening symptoms to emergency services.

---

## 2. Key Features

- **Modern Healthcare UI:** Clean, responsive ChatGPT-style interface built with vanilla HTML5, CSS3, and JavaScript (no heavy frontend frameworks like React).
- **Dual-Engine Architecture:**
  - **Online Mode:** Connects to any standard OpenAI-compatible LLM endpoint using `AI_API_KEY`, `AI_API_URL`, and `AI_MODEL`.
  - **Local Verified Fallback Mode:** Operates 100% offline using a curated medical knowledge base when an external API is unconfigured or unreachable.
- **Emergency Triage Detection:** Scans user queries in real-time for acute keywords (e.g., *chest pain*, *difficulty breathing*, *stroke*, *severe bleeding*, *seizure*) and surfaces high-visibility emergency warnings and direct dial buttons (`EMERGENCY_NUMBER=112`).
- **Persistent Conversation History:** Conversations and consultation threads are automatically saved in a local SQLite database (`database/medicare.db`).
- **Structured Explanations & Citations:** Every response breaks down causes, symptoms, self-care, warning signs, and links to verified global sources (WHO, CDC, NHS, MedlinePlus).
- **Doctor Appointment Handoff:** Integrates a configurable appointment scheduling link (`BOOKING_URL`) for seamless user referral to professional medical care.
- **Voice Input:** Integrated browser speech recognition for accessible hands-free consultation.
- **Beginner-Friendly & Self-Contained:** Zero complicated dependencies — runs out of the box with standard Python libraries and SQLite.

---

## 3. Technology Stack

| Layer | Technology | Justification |
|---|---|---|
| **Frontend** | HTML5, CSS3 (Variables), Vanilla JavaScript | Ultra-fast load times, zero build steps, complete browser compatibility. |
| **Backend** | Python 3.10+, Flask 3.0 | Lightweight, idiomatic Python web framework ideal for REST APIs. |
| **Database** | SQLite3 (via built-in `sqlite3` module) | Serverless, zero-configuration relational database stored locally. |
| **Configuration** | `python-dotenv` | Clean 12-factor application secrets management via `.env`. |
| **External HTTP** | `requests` | Resilient HTTP client with timeouts for calling external AI APIs. |

---

## 4. Architecture

```text
       +-------------------------------------------------------+
       |             Browser (Client Presentation)             |
       |  Vanilla JS (app.js) + HTML5 (index.html) + CSS3 UI   |
       +-------------------------------------------------------+
                                  │
                       HTTP / JSON REST API
                                  ▼
       +-------------------------------------------------------+
       |             Flask Web Server (app.py)                 |
       |     • Routing & Input Sanitization                    |
       |     • Message Length Validation                       |
       |     • Conversation Session Management                 |
       +-------------------------------------------------------+
                  │                                   │
                  ▼                                   ▼
       +--------------------+               +--------------------+
       | SQLite Database    |               | AI Service Layer   |
       | (database.py)      |               | (ai_service.py)    |
       | • conversations    |               | • Emergency Check  |
       | • messages         |               +--------------------+
       | • medical_sources  |                         │
       +--------------------+            ┌────────────┴────────────┐
                                         ▼                         ▼
                              [External AI API]        [Local Verified Fallback]
                              (OpenAI / Custom)        (medical_knowledge.py)
```

---

## 5. Project Directory Structure

```text
medicare-chatbot/
│
├── app.py                     # Primary Flask REST API & Web Server
├── ai_service.py              # AI orchestration & fallback engine
├── database.py                # SQLite connection & database operations
├── medical_knowledge.py       # Curated offline medical knowledge & emergency rules
├── requirements.txt           # Minimal Python dependencies
├── .env.example               # Template for environment configuration
├── .env                       # Active environment configuration
├── .gitignore                 # Files excluded from git tracking
├── README.md                  # Comprehensive project documentation
│
├── database/
│   └── medicare.db            # SQLite database file (auto-generated at start)
│
├── templates/
│   ├── index.html             # Healthcare chat interface HTML5 template
│   ├── login.html             # User login portal template
│   └── register.html          # New account registration template
│
├── static/
│   ├── css/
│   │   └── style.css          # Design system, CSS variables & animations
│   └── js/
│       └── app.js             # Client state, event listeners & Markdown parser
│
└── data/
    └── medical_sources.json   # Verified authoritative medical sources
```

---

## 6. Installation & Quick Start

### Step 1: Clone or Open the Workspace
```bash
cd "c:\medicare chatbot"
```

### Step 2: Set Up Python Virtual Environment (Recommended)

**On Windows:**
```powershell
python -m venv venv
venv\Scripts\activate
```

**On macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables
Copy `.env.example` to `.env` if not already created:
```bash
cp .env.example .env
```

Edit `.env` to configure your settings:
```ini
# Flask Server Config
PORT=5000
FLASK_DEBUG=True

# External AI Service (Optional - leave empty for offline fallback mode)
AI_API_KEY=
AI_API_URL=https://api.openai.com/v1/chat/completions
AI_MODEL=gpt-3.5-turbo

# Emergency Services Number (112 for India, 911 for USA)
EMERGENCY_NUMBER=112

# Doctor Appointment Booking Link
BOOKING_URL=https://www.practo.com
```

### Step 5: Start the Application
```bash
python app.py
```

### Step 6: Open in Your Web Browser
Navigate to:
```text
http://127.0.0.1:5000
```

---

## 7. REST API Endpoints

| Method | Endpoint | Description | Request Body | Response |
|---|---|---|---|---|
| `GET` | `/` | Web interface | None | HTML page |
| `GET` | `/api/health` | Health & service check | None | `{"status": "ok", ...}` |
| `GET` | `/api/config` | Public safe config | None | `{"emergency_number": "112", ...}` |
| `GET` | `/api/conversations` | List past conversations | None | `{"conversations": [...]}` |
| `POST` | `/api/conversations` | Create conversation container | `{"title": "..."}` | `{"id": 1, ...}` |
| `GET` | `/api/conversations/<id>/messages` | Retrieve message history | None | `{"messages": [...]}` |
| `POST` | `/api/chat` | Send health query & get response | `{"conversation_id": 1, "message": "..."}` | `{"reply": "...", "sources": [...]}` |
| `DELETE` | `/api/conversations/<id>` | Delete conversation thread | None | `{"status": "deleted"}` |
| `POST` | `/api/conversations/<id>/clear` | Clear conversation messages | None | `{"status": "cleared"}` |
| `GET` | `/api/sources` | Get verified medical reference sources | None | `{"sources": [...]}` |

---

## 8. Database Schema

The database initializes automatically on startup in `database/medicare.db`.

### 1. `conversations`
```sql
CREATE TABLE conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. `messages`
```sql
CREATE TABLE messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    role TEXT NOT NULL,          -- 'user' or 'assistant'
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
);
```

### 3. `medical_sources`
```sql
CREATE TABLE medical_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    category TEXT
);
```

---

## 9. Fallback & Safety Protocol

1. **Emergency Triage Detection:**
   - Any query containing critical phrases (e.g. *chest pain*, *trouble breathing*, *fainting*, *stroke symptoms*, *suicidal thoughts*) triggers an immediate emergency warning.
   - The user is instructed not to rely on the chatbot and provided with a one-click dial button to `112`.

2. **Verified Offline Fallback:**
   - If no valid API key is present or if the external API is unreachable/times out, the chatbot routes queries through `medical_knowledge.py`.
   - The knowledge base covers common ailments: **Fever, Headache, Flu, Common Cold, Dehydration, Diabetes, Hypertension, Cough, Sore Throat, Stomach Discomfort, Basic First Aid, and Doctor Consultation Guidelines**.
   - Displays a green status badge in the chat: `Using verified local information`.

---

## 10. Viva & Presentation Guide

### High-Frequency Viva Questions & Answers

1. **Why did you use SQLite instead of MySQL or PostgreSQL?**
   > *Answer:* SQLite is a serverless, zero-configuration relational database stored directly in a file on disk. For a single-user or demonstrative healthcare assistant, SQLite eliminates the overhead of managing a database server process while providing full ACID transactions and SQL querying.

2. **How does the chatbot prevent medical misinformation?**
   > *Answer:* By design, the assistant acts strictly as an educational guide. It never issues diagnoses or prescriptions. If an external AI is connected, the system prompt strictly instructs it to avoid certainty. In offline mode, answers are drawn only from verified health authorities (WHO, CDC, NHS).

3. **How does the fallback mechanism work?**
   > *Answer:* In `ai_service.py`, before invoking an external API, the service validates whether a real key is present. If missing or if the network request fails/times out, it seamlessly searches `medical_knowledge.py` via keyword scoring, returning a structured response without crashing or showing raw errors.

4. **Why did you choose vanilla JavaScript over React or Vue?**
   > *Answer:* Vanilla JS requires no Node build steps, no webpack/vite bundling, and loads instantaneously in any browser. It keeps the project lightweight, portable, and easily understandable for academic review.

5. **How are conversations persisted across browser refreshes?**
   > *Answer:* The frontend saves conversation states in SQLite via REST calls (`/api/conversations`). On page load, `app.js` queries the backend to populate past conversation titles in the sidebar.


## Login and registration (added)

- Start the app with `python app.py` and open `http://127.0.0.1:5000`.
- Unauthenticated visitors are redirected to `/login`.
- Use **Create an account** to register; passwords are stored with Werkzeug password hashing in SQLite.
- Log out using the button in the app header.
- Optional: set a long random `FLASK_SECRET_KEY` in `.env` before sharing or deploying. The default secret is for local development only.
- This is a student/demo app. Conversations are currently stored in the existing shared app database, so do not use it for real sensitive patient data or deploy it publicly without adding per-user data isolation, CSRF protection, HTTPS, and production configuration.
