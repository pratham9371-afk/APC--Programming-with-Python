"""
AI Service module for Medicare Assistant.
Orchestrates responses following the strict priority pipeline:
  1. Emergency Triage Detection
  2. Conversational & Greeting Intent Handling
  3. External AI API (Primary Intelligence Layer)
  4. Local Verified Medical Knowledge Fallback (When AI API is offline/unavailable)
  5. Graceful Service Limitation Notice (For unindexed queries when AI is offline)
"""

import os
import re
import requests
from dotenv import load_dotenv
from medical_knowledge import check_emergency, find_medical_topic

# Load environment configuration
load_dotenv()

AI_API_KEY = os.getenv("AI_API_KEY", "").strip()
AI_API_URL = os.getenv("AI_API_URL", "https://api.openai.com/v1/chat/completions").strip()
AI_MODEL = os.getenv("AI_MODEL", "gpt-3.5-turbo").strip()
BOOKING_URL = os.getenv("BOOKING_URL", "https://www.mohfw.gov.in/?utm_source=chatgpt.com").strip()
EMERGENCY_NUMBER = os.getenv("EMERGENCY_NUMBER", "112").strip()

# Terminal startup logging for developer clarity
def is_api_configured() -> bool:
    """Checks whether a valid external AI API key is configured."""
    return (
        bool(AI_API_KEY) and
        not AI_API_KEY.lower().startswith("your_") and
        not AI_API_KEY.lower().startswith("sk-placeholder") and
        len(AI_API_KEY) > 10
    )

if not is_api_configured():
    print("--------------------------------------------------")
    print(" WARNING: AI API is not configured.")
    print(" Using local fallback mode.")
    print("--------------------------------------------------")
else:
    print(f" [AI Service] Primary AI API configured (Model: {AI_MODEL}).")


SYSTEM_PROMPT = """You are Medicare Assistant, a friendly, professional, and knowledgeable educational medical information assistant.

Your role is to provide clear, helpful, and evidence-based health guidance in accessible language.

CRITICAL INSTRUCTIONS:
- Explain conditions, symptoms, and wellness topics with clarity and empathy.
- For medical questions (e.g. fever, headaches, diabetes, dengue, flu):
  • Provide a clear overview and possible causes.
  • List common symptoms in bullet points.
  • Suggest safe, practical self-care and prevention measures.
  • Highlight warning signs and red flags.
  • Clarify when to seek clinical evaluation from a qualified physician.
- Maintain safety: Never claim certainty about a diagnosis. Use safe language ("can be associated with", "possible causes include").
- Never prescribe medication dosages or give unsafe prescription instructions.
- If emergency symptoms are described (chest pain, shortness of breath, sudden numbness, unconsciousness), instruct immediate emergency care.
- Never pretend to be a doctor conducting an in-person physical examination.

Format your responses with clean Markdown:
- Use ### for section headings
- Use bold text for key terms
- Use bullet points (•) for lists
"""


def check_conversational_phrase(text: str):
    """
    Detects natural conversation, greetings, gratitude, and farewells.
    Returns (is_conversational: bool, reply_text: str or None)
    """
    if not text:
        return False, None

    cleaned = text.strip().lower()
    # Remove surrounding punctuation
    cleaned_no_punct = re.sub(r"^[^\w]+|[^\w]+$", "", cleaned)

    # 1. Greetings
    # Matches: hi, hello, hey, good morning, good evening, hey there, hello assistant, hi medicare, etc.
    greeting_pattern = r"^(hi|hello|hey|hola|greetings|good\s+(morning|afternoon|evening|day))(\s+(there|medicare|assistant|bot|doc|doctor|friend|everyone))?$"
    if re.match(greeting_pattern, cleaned_no_punct):
        return True, (
            "Hi! 👋 I'm **Medicare Assistant**.\n\n"
            "I can help you with general health information, symptoms, wellness questions, "
            "and reliable medical resources.\n\n"
            "What would you like to know today?"
        )

    # 2. Thanks / Gratitude
    # Matches: thanks, thank you, thank you so much, thx, appreciate it, etc.
    thanks_pattern = r"^(thanks|thank\s+you|thx|many\s+thanks|appreciate\s+it|much\s+appreciated)(\s+(so\s+much|a\s+lot|very\s+much|assistant|medicare))?$"
    if re.match(thanks_pattern, cleaned_no_punct):
        return True, "You're welcome! If you have another health question, feel free to ask."

    # 3. Acknowledgements / Affirmations
    # Matches: ok, okay, alright, all right, got it, understood, cool, sure, fine, noted
    ack_pattern = r"^(ok|okay|alright|all\s+right|got\s+it|understood|cool|sure|fine|noted|k|kk)$"
    if re.match(ack_pattern, cleaned_no_punct):
        return True, "Let me know if there is anything else you'd like to ask about symptoms, wellness, or health topics!"

    # 4. Farewells
    # Matches: bye, goodbye, see you, take care, good night, bye bye
    farewell_pattern = r"^(bye|goodbye|see\s+you|see\s+ya|take\s+care|good\s+night|bye\s+bye)(\s+(now|assistant|medicare))?$"
    if re.match(farewell_pattern, cleaned_no_punct):
        return True, "Take care and stay healthy! Feel free to reach out whenever you have more questions."

    # 5. Identity & Capabilities
    # Matches: who are you, what can you do, help, how can you help
    identity_pattern = r"^(who\s+are\s+you|what\s+are\s+you|what\s+can\s+you\s+do|how\s+can\s+you\s+help(\s+me)?|help)$"
    if re.match(identity_pattern, cleaned_no_punct):
        return True, (
            "I'm **Medicare Assistant**, an educational health companion! 🩺\n\n"
            "Here is how I can assist you:\n"
            "• **Symptom Information:** Explain common symptoms and possible causes.\n"
            "• **General Self-Care:** Safe home practices and wellness tips.\n"
            "• **Warning Signs:** Guidance on when you should visit a doctor.\n"
            "• **Emergency Guidance:** Rapid guidance for critical medical concerns.\n"
            "• **Verified Sources:** Trusted links from WHO, CDC, NHS, and MedlinePlus.\n\n"
            "*Note: I provide educational information and do not replace professional medical advice.*"
        )

    return False, None


def format_fallback_response(topic_data):
    """Formats a curated medical topic into structured markdown text."""
    parts = []
    parts.append(f"### {topic_data['title']}")
    parts.append(f"{topic_data['explanation']}\n")

    if topic_data.get("causes"):
        parts.append("### Possible Causes")
        for cause in topic_data["causes"]:
            parts.append(f"• {cause}")
        parts.append("")

    if topic_data.get("symptoms"):
        parts.append("### Common Symptoms")
        for sym in topic_data["symptoms"]:
            parts.append(f"• {sym}")
        parts.append("")

    if topic_data.get("self_care"):
        parts.append("### General Self-Care")
        for care in topic_data["self_care"]:
            parts.append(f"• {care}")
        parts.append("")

    if topic_data.get("warning_signs"):
        parts.append("### ⚠️ Warning Signs")
        for warn in topic_data["warning_signs"]:
            parts.append(f"• {warn}")
        parts.append("")

    if topic_data.get("when_to_see_doctor"):
        parts.append("### When to See a Doctor")
        parts.append(f"{topic_data['when_to_see_doctor']}\n")

    return "\n".join(parts)


def get_emergency_response(keyword: str):
    """Generates an immediate high-priority warning response for life-threatening keywords."""
    return {
        "reply": (
            "⚠️ **EMERGENCY WARNING**\n\n"
            f"You mentioned **'{keyword}'**, which may indicate an urgent, life-threatening medical situation.\n\n"
            "**Immediate Action Required:**\n"
            f"• Please contact your local emergency medical service immediately (Dial **{EMERGENCY_NUMBER}**).\n"
            "• Or go directly to the nearest hospital emergency department.\n"
            "• If you are alone, inform a family member, neighbor, or someone nearby immediately.\n\n"
            "*Do not wait for symptoms to pass and do not rely on this automated chatbot for emergency diagnosis or treatment.*"
        ),
        "sources": [
            {"title": "WHO - Health Emergencies", "url": "https://www.who.int/emergencies"},
            {"title": f"Emergency Medical Services ({EMERGENCY_NUMBER})", "url": f"tel:{EMERGENCY_NUMBER}"}
        ],
        "is_emergency": True,
        "is_fallback": True,
        "fallback_badge": "Emergency Protocol Triggered",
        "emergency_number": EMERGENCY_NUMBER,
        "booking_url": BOOKING_URL
    }


def generate_response(message: str, conversation_history=None):
    """
    Main response generation pipeline following the strict priority:
      1. Emergency keyword triage
      2. Conversational phrases & greetings
      3. Primary External AI API (passes multi-turn context)
      4. Local Verified Medical Knowledge Fallback (if AI API unavailable)
      5. Graceful Service Limitation Notice (if query is unknown and AI is offline)
    """
    if conversation_history is None:
        conversation_history = []

    # -------------------------------------------------------------
    # 1. EMERGENCY KEYWORD DETECTION (Top Priority)
    # -------------------------------------------------------------
    is_emergency, keyword = check_emergency(message)
    if is_emergency:
        return get_emergency_response(keyword)

    # -------------------------------------------------------------
    # 2. CONVERSATIONAL / GREETING DETECTION
    # -------------------------------------------------------------
    is_conv, conv_reply = check_conversational_phrase(message)
    if is_conv:
        return {
            "reply": conv_reply,
            "sources": [],
            "is_emergency": False,
            "is_fallback": False,
            "fallback_badge": None,
            "emergency_number": EMERGENCY_NUMBER,
            "booking_url": BOOKING_URL
        }

    # -------------------------------------------------------------
    # 3. PRIMARY SYSTEM: EXTERNAL AI API
    # -------------------------------------------------------------
    if is_api_configured():
        try:
            # Prepare messages payload with full conversation history
            messages_payload = [{"role": "system", "content": SYSTEM_PROMPT}]

            # Append past context (last 8 messages)
            for msg in conversation_history[-8:]:
                role = "assistant" if msg.get("role") == "assistant" else "user"
                content = msg.get("message") or msg.get("content") or ""
                if content.strip():
                    messages_payload.append({"role": role, "content": content.strip()})

            # Append current question
            messages_payload.append({"role": "user", "content": message.strip()})

            headers = {
                "Authorization": f"Bearer {AI_API_KEY}",
                "Content-Type": "application/json"
            }

            payload = {
                "model": AI_MODEL,
                "messages": messages_payload,
                "temperature": 0.4,
                "max_tokens": 750
            }

            response = requests.post(AI_API_URL, headers=headers, json=payload, timeout=8)

            if response.status_code == 200:
                data = response.json()
                reply_text = data["choices"][0]["message"]["content"].strip()

                # Match relevant sources or provide default trusted authorities
                matched = find_medical_topic(message)
                sources = matched["sources"] if matched else [
                    {"title": "WHO - Health Topics", "url": "https://www.who.int"},
                    {"title": "CDC - Health Conditions", "url": "https://www.cdc.gov"},
                    {"title": "NHS - Health A to Z", "url": "https://www.nhs.uk"}
                ]

                return {
                    "reply": reply_text,
                    "sources": sources,
                    "is_emergency": False,
                    "is_fallback": False,
                    "fallback_badge": None,
                    "emergency_number": EMERGENCY_NUMBER,
                    "booking_url": BOOKING_URL
                }
            else:
                print(f"[AI Service] API error HTTP {response.status_code}: {response.text[:200]}")
        except Exception as e:
            print(f"[AI Service] External API call failed: {e}. Switching to local verified fallback.")

    # -------------------------------------------------------------
    # 4. FALLBACK SYSTEM: LOCAL VERIFIED MEDICAL KNOWLEDGE
    # -------------------------------------------------------------
    topic_data = find_medical_topic(message)

    if topic_data:
        reply_text = format_fallback_response(topic_data)
        sources = topic_data.get("sources", [])
        return {
            "reply": reply_text,
            "sources": sources,
            "is_emergency": False,
            "is_fallback": True,
            "fallback_badge": "Using verified local information",
            "emergency_number": EMERGENCY_NUMBER,
            "booking_url": BOOKING_URL
        }

    # -------------------------------------------------------------
    # 5. UNKNOWN TOPIC + AI SERVICE LIMITATION
    # -------------------------------------------------------------
    return {
        "reply": (
            "Sorry, I'm temporarily unable to connect to my AI service. "
            "You can try again in a moment, or I can help with some common health topics "
            "such as **fever**, **headache**, **diabetes**, **dehydration**, **cough**, and **flu**."
        ),
        "sources": [
            {"title": "WHO - World Health Organization", "url": "https://www.who.int"},
            {"title": "CDC - Diseases & Conditions", "url": "https://www.cdc.gov"},
            {"title": "NHS - Health Guidance", "url": "https://www.nhs.uk"}
        ],
        "is_emergency": False,
        "is_fallback": True,
        "fallback_badge": "Service Notice",
        "emergency_number": EMERGENCY_NUMBER,
        "booking_url": BOOKING_URL
    }
