"""
Automated Comprehensive Test Suite for Medicare Assistant.
Validates all requirements:
  - Emergency keyword triage
  - Conversational phrases (hi, hello, thanks, bye, etc.)
  - Primary AI API / Local fallback behavior
  - Clear message handling & service limitation notice
  - SQLite database persistence & cascade deletes
"""

import os
import json
import unittest
from app import app
import database as db
import ai_service


class MedicareChatbotTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app
        self.client = self.app.test_client()
        db.init_db()

    def test_01_database_initialization(self):
        """Verifies database tables exist and sources are seeded."""
        sources = db.get_medical_sources()
        self.assertGreater(len(sources), 0, "Medical sources table should be seeded.")
        print(f" [PASS] Database initialized with {len(sources)} medical sources.")

    def test_02_health_endpoint(self):
        """Tests /api/health."""
        res = self.client.get("/api/health")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data.get("status"), "ok")
        print(" [PASS] /api/health returned 200 OK.")

    def test_03_config_endpoint(self):
        """Tests /api/config returns safe public config and no secrets."""
        res = self.client.get("/api/config")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("emergency_number", data)
        self.assertIn("booking_url", data)
        self.assertNotIn("AI_API_KEY", data)
        self.assertNotIn("api_key", str(data).lower())
        print(f" [PASS] /api/config safe: Emergency={data['emergency_number']}, Booking={data['booking_url']}")

    def test_04_conversational_greetings_and_phrases(self):
        """Tests natural handling of 'hi', 'hello', 'thanks', 'okay', 'bye'."""
        cases = [
            ("hi", "Hi! 👋 I'm **Medicare Assistant**"),
            ("hello", "Hi! 👋 I'm **Medicare Assistant**"),
            ("hey", "Hi! 👋 I'm **Medicare Assistant**"),
            ("good morning", "Hi! 👋 I'm **Medicare Assistant**"),
            ("good evening", "Hi! 👋 I'm **Medicare Assistant**"),
            ("Hi there", "Hi! 👋 I'm **Medicare Assistant**"),
            ("Hey medicare", "Hi! 👋 I'm **Medicare Assistant**"),
            ("thanks", "You're welcome"),
            ("thank you", "You're welcome"),
            ("okay", "Let me know"),
            ("bye", "Take care and stay healthy")
        ]

        for prompt, expected_substr in cases:
            res = self.client.post("/api/chat", json={"message": prompt})
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertIn(expected_substr.lower(), data["reply"].lower(), f"Failed for prompt: {prompt}")
            self.assertFalse(data.get("is_fallback"), f"Greeting '{prompt}' should not be marked fallback")
            self.assertIsNone(data.get("fallback_badge"), f"Greeting '{prompt}' should have no fallback badge")
            self.assertFalse(data.get("is_emergency"))
            print(f" [PASS] Conversational phrase correctly handled: '{prompt}'")

    def test_05_chat_flow_and_fallback(self):
        """Tests medical chat message processing with local medical fallback."""
        payload = {
            "message": "What are the symptoms of fever?"
        }
        res = self.client.post("/api/chat", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        
        self.assertIn("reply", data)
        self.assertIn("sources", data)
        self.assertIn("conversation_id", data)
        self.assertTrue(data.get("is_fallback"))
        self.assertEqual(data.get("fallback_badge"), "Using verified local information")
        self.assertFalse(data.get("is_emergency"))
        self.assertTrue("Fever" in data["reply"] or "temperature" in data["reply"].lower())

        conv_id = data["conversation_id"]

        # Check messages persisted in DB
        res_msgs = self.client.get(f"/api/conversations/{conv_id}/messages")
        self.assertEqual(res_msgs.status_code, 200)
        messages = res_msgs.get_json()["messages"]
        self.assertEqual(len(messages), 2)
        print(f" [PASS] Medical query & fallback verified for Conv ID {conv_id}.")

    def test_06_dengue_symptoms_fallback(self):
        """Tests dengue symptoms query in fallback mode."""
        res = self.client.post("/api/chat", json={"message": "What are symptoms of dengue?"})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("dengue", data["reply"].lower())
        self.assertEqual(data.get("fallback_badge"), "Using verified local information")
        print(" [PASS] Dengue symptoms successfully handled in fallback mode.")

    def test_07_unknown_topic_service_limitation(self):
        """Tests unknown non-medical question when AI API is unavailable."""
        res = self.client.post("/api/chat", json={"message": "Tell me about rocket propulsion and mars rover"})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("temporarily unable to connect to my ai service", data["reply"].lower())
        self.assertEqual(data.get("fallback_badge"), "Service Notice")
        self.assertNotIn("General Health Information\nI am currently operating with", data["reply"])
        print(" [PASS] Unknown topic returns clean service limitation notice (not bad generic library dump).")

    def test_08_followup_chat_flow(self):
        """Tests sending a follow-up message in the same conversation."""
        # First question
        res1 = self.client.post("/api/chat", json={"message": "What is diabetes?"})
        conv_id = res1.get_json()["conversation_id"]

        # Follow-up
        res2 = self.client.post("/api/chat", json={
            "conversation_id": conv_id,
            "message": "What causes it and how can I stay healthy?"
        })
        self.assertEqual(res2.status_code, 200)
        data2 = res2.get_json()
        self.assertEqual(data2["conversation_id"], conv_id)

        # Verify DB has 4 messages
        res_msgs = self.client.get(f"/api/conversations/{conv_id}/messages")
        messages = res_msgs.get_json()["messages"]
        self.assertEqual(len(messages), 4)
        print(f" [PASS] Follow-up conversation context verified (Total messages: {len(messages)}).")

    def test_09_emergency_detection(self):
        """Tests that emergency keywords trigger emergency alert and protocol."""
        emergency_prompts = [
            "I have severe chest pain and difficulty breathing",
            "Someone is unconscious after a seizure",
            "Severe bleeding that won't stop"
        ]

        for p in emergency_prompts:
            res = self.client.post("/api/chat", json={"message": p})
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertTrue(data.get("is_emergency"), f"Should trigger emergency for: {p}")
            self.assertIn("EMERGENCY WARNING", data.get("reply"))
            self.assertEqual(data.get("emergency_number"), "112")
            print(f" [PASS] Emergency correctly triggered for: '{p}'")

    def test_10_input_validation(self):
        """Tests validation for empty messages and oversized payloads."""
        # Empty message
        res1 = self.client.post("/api/chat", json={"message": "   "})
        self.assertEqual(res1.status_code, 400)

        # Huge payload (>2000 chars)
        res3 = self.client.post("/api/chat", json={"message": "x" * 2500})
        self.assertEqual(res3.status_code, 400)
        print(" [PASS] Input validation rules verified (empty and >2000 characters).")

    def test_11_clear_and_delete_conversation(self):
        """Tests clearing and deleting conversations."""
        res = self.client.post("/api/chat", json={"message": "Test headache remedy"})
        conv_id = res.get_json()["conversation_id"]

        # Clear
        res_clear = self.client.post(f"/api/conversations/{conv_id}/clear")
        self.assertEqual(res_clear.status_code, 200)

        # Delete
        res_del = self.client.delete(f"/api/conversations/{conv_id}")
        self.assertEqual(res_del.status_code, 200)
        print(f" [PASS] Conversation clear and delete verified on Conv ID {conv_id}.")

    def test_12_auth_and_page_rendering(self):
        """Tests user registration, login, authenticated page rendering, and logout."""
        test_email = "testuser@example.com"
        db.delete_user_by_email(test_email)

        try:
            # 1. Unauthenticated request to / should redirect to login
            res = self.client.get("/")
            self.assertEqual(res.status_code, 302)
            self.assertIn("/login", res.headers.get("Location", ""))

            # 2. GET /login should render 200
            res = self.client.get("/login")
            self.assertEqual(res.status_code, 200)
            self.assertIn(b"Welcome back", res.data)

            # 3. GET /register should render 200
            res = self.client.get("/register")
            self.assertEqual(res.status_code, 200)
            self.assertIn(b"Create your account", res.data)

            # 4. POST /register with valid details
            reg_payload = {
                "name": "Dr. Sarah",
                "email": test_email,
                "password": "SecurePassword123!",
                "confirm_password": "SecurePassword123!"
            }
            res = self.client.post("/register", data=reg_payload, follow_redirects=True)
            self.assertEqual(res.status_code, 200)
            # Should now successfully render index.html without template BuildError
            self.assertIn(b"Medicare Assistant", res.data)
            self.assertIn(b"Signed in as Dr. Sarah", res.data)
            self.assertIn(b"Log out", res.data)

            # 5. Access / while authenticated
            res = self.client.get("/")
            self.assertEqual(res.status_code, 200)
            self.assertIn(b"Signed in as Dr. Sarah", res.data)

            # 6. Duplicate registration should be rejected
            res = self.client.post("/register", data=reg_payload)
            self.assertIn(res.status_code, [400, 302])

            # 7. Logout
            res = self.client.post("/logout", follow_redirects=True)
            self.assertEqual(res.status_code, 200)
            self.assertIn(b"Welcome back", res.data)

            # 8. Access / after logout should redirect to login
            res = self.client.get("/")
            self.assertEqual(res.status_code, 302)

            # 9. Login with invalid password
            res = self.client.post("/login", data={"email": test_email, "password": "WrongPassword"})
            self.assertEqual(res.status_code, 401)

            # 10. Login with correct credentials
            res = self.client.post("/login", data={"email": test_email, "password": "SecurePassword123!"}, follow_redirects=True)
            self.assertEqual(res.status_code, 200)
            self.assertIn(b"Signed in as Dr. Sarah", res.data)
            print(" [PASS] User authentication flow (register, login, index render, logout) fully verified.")
        finally:
            db.delete_user_by_email(test_email)


if __name__ == "__main__":
    unittest.main()
