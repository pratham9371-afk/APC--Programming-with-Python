/**
 * Medicare Assistant — Frontend Application Engine
 * Pure Vanilla JavaScript: No React/Vue dependencies.
 */

document.addEventListener("DOMContentLoaded", () => {
  // Application State
  const state = {
    currentConversationId: null,
    conversations: [],
    isGenerating: false,
    emergencyNumber: "112",
    bookingUrl: "https://www.practo.com",
    lastUserMessage: ""
  };

  // DOM Elements
  const chatContainer = document.getElementById("chatContainer");
  const messagesList = document.getElementById("messagesList");
  const welcomeScreen = document.getElementById("welcomeScreen");
  const typingIndicator = document.getElementById("typingIndicator");
  const chatInput = document.getElementById("chatInput");
  const sendBtn = document.getElementById("sendBtn");
  const voiceBtn = document.getElementById("voiceBtn");
  const newChatBtn = document.getElementById("newChatBtn");
  const conversationsList = document.getElementById("conversationsList");
  const currentChatTitle = document.getElementById("currentChatTitle");
  const clearChatBtn = document.getElementById("clearChatBtn");
  const headerDoctorLink = document.getElementById("headerDoctorLink");
  const headerEmergencyLink = document.getElementById("headerEmergencyLink");
  const emergencyHeaderLabel = document.getElementById("emergencyHeaderLabel");
  const modalCallEmergencyBtn = document.getElementById("modalCallEmergencyBtn");
  const modalEmergencyCallText = document.getElementById("modalEmergencyCallText");

  // Mobile elements
  const sidebar = document.getElementById("sidebar");
  const sidebarBackdrop = document.getElementById("sidebarBackdrop");
  const openSidebarBtn = document.getElementById("openSidebarBtn");
  const closeSidebarBtn = document.getElementById("closeSidebarBtn");

  // Modals
  const resourcesModal = document.getElementById("resourcesModal");
  const emergencyModal = document.getElementById("emergencyModal");
  const aboutModal = document.getElementById("aboutModal");
  const openResourcesBtn = document.getElementById("openResourcesBtn");
  const openEmergencyBtn = document.getElementById("openEmergencyBtn");
  const openAboutBtn = document.getElementById("openAboutBtn");
  const sourcesContainer = document.getElementById("sourcesContainer");

  // ==========================================================================
  // Initialization
  // ==========================================================================
  async function init() {
    setupEventListeners();
    await fetchConfig();
    await loadConversations();
    checkInputState();
  }

  // ==========================================================================
  // API Calls
  // ==========================================================================
  async function fetchConfig() {
    try {
      const res = await fetch("/api/config");
      if (res.ok) {
        const config = await res.json();
        state.emergencyNumber = config.emergency_number || "112";
        state.bookingUrl = config.booking_url || "https://www.practo.com";

        // Update UI links
        if (headerDoctorLink) headerDoctorLink.href = state.bookingUrl;
        if (headerEmergencyLink) {
          headerEmergencyLink.href = `tel:${state.emergencyNumber}`;
          if (emergencyHeaderLabel) emergencyHeaderLabel.textContent = `Emergency (${state.emergencyNumber})`;
        }
        if (modalCallEmergencyBtn) {
          modalCallEmergencyBtn.href = `tel:${state.emergencyNumber}`;
        }
        if (modalEmergencyCallText) {
          modalEmergencyCallText.textContent = `Call Emergency Services (${state.emergencyNumber})`;
        }
      }
    } catch (err) {
      console.warn("Could not fetch config from server:", err);
    }
  }

  async function loadConversations() {
    try {
      const res = await fetch("/api/conversations");
      if (res.ok) {
        const data = await res.json();
        state.conversations = data.conversations || [];
        renderSidebarConversations();
      }
    } catch (err) {
      console.error("Failed to load conversations:", err);
    }
  }

  async function loadConversationMessages(convId) {
    try {
      showLoading(true);
      const res = await fetch(`/api/conversations/${convId}/messages`);
      if (res.ok) {
        const data = await res.json();
        state.currentConversationId = convId;
        currentChatTitle.textContent = data.conversation.title || "Consultation";
        
        // Hide welcome screen
        welcomeScreen.style.display = "none";
        messagesList.innerHTML = "";

        // Render each message
        (data.messages || []).forEach(msg => {
          appendMessageToUI(msg.role, msg.message, {
            skipAnimation: true,
            createdAt: msg.created_at
          });
        });

        renderSidebarConversations();
        scrollToBottom();
      }
    } catch (err) {
      console.error("Failed to load messages:", err);
    } finally {
      showLoading(false);
    }
  }

  async function sendMessage(text) {
    const message = (text || chatInput.value).trim();
    if (!message || state.isGenerating) return;

    state.lastUserMessage = message;
    state.isGenerating = true;
    chatInput.value = "";
    autoResizeTextarea();
    checkInputState();

    // Hide welcome screen
    welcomeScreen.style.display = "none";

    // Add user message to UI
    appendMessageToUI("user", message, { createdAt: new Date().toISOString() });
    scrollToBottom();

    // Show typing dots
    showLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversation_id: state.currentConversationId,
          message: message
        })
      });

      const data = await res.json();

      if (res.ok) {
        state.currentConversationId = data.conversation_id;
        currentChatTitle.textContent = data.conversation_title;

        // Render assistant response
        appendMessageToUI("assistant", data.reply, {
          sources: data.sources,
          isEmergency: data.is_emergency,
          isFallback: data.is_fallback,
          fallbackBadge: data.fallback_badge,
          emergencyNumber: data.emergency_number || state.emergencyNumber,
          bookingUrl: data.booking_url || state.bookingUrl,
          createdAt: new Date().toISOString()
        });

        // Refresh conversation list in sidebar
        loadConversations();
      } else {
        appendMessageToUI("assistant", data.reply || "Something went wrong. Please try again.", {
          isEmergency: false,
          isFallback: true
        });
      }
    } catch (err) {
      console.error("Error sending message:", err);
      appendMessageToUI("assistant", "I am having trouble connecting right now. Please check your network and try again.", {
        isFallback: true
      });
    } finally {
      showLoading(false);
      state.isGenerating = false;
      scrollToBottom();
      chatInput.focus();
    }
  }

  async function deleteConversation(convId, event) {
    if (event) event.stopPropagation();
    if (!confirm("Are you sure you want to delete this conversation?")) return;

    try {
      const res = await fetch(`/api/conversations/${convId}`, { method: "DELETE" });
      if (res.ok) {
        if (state.currentConversationId === convId) {
          startNewChat();
        }
        await loadConversations();
      }
    } catch (err) {
      console.error("Failed to delete conversation:", err);
    }
  }

  async function clearCurrentChat() {
    if (!state.currentConversationId) {
      startNewChat();
      return;
    }

    if (!confirm("Clear all messages in this conversation?")) return;

    try {
      const res = await fetch(`/api/conversations/${state.currentConversationId}/clear`, { method: "POST" });
      if (res.ok) {
        messagesList.innerHTML = "";
        welcomeScreen.style.display = "flex";
      }
    } catch (err) {
      console.error("Failed to clear chat:", err);
    }
  }

  function startNewChat() {
    state.currentConversationId = null;
    currentChatTitle.textContent = "Medicare Assistant";
    messagesList.innerHTML = "";
    welcomeScreen.style.display = "flex";
    renderSidebarConversations();
    closeMobileSidebar();
    chatInput.value = "";
    autoResizeTextarea();
    checkInputState();
    chatInput.focus();
  }

  // ==========================================================================
  // UI Rendering
  // ==========================================================================
  function renderSidebarConversations() {
    if (!conversationsList) return;

    if (state.conversations.length === 0) {
      conversationsList.innerHTML = '<div class="sidebar-empty">No conversations yet</div>';
      return;
    }

    conversationsList.innerHTML = "";
    state.conversations.forEach(conv => {
      const item = document.createElement("div");
      item.className = `conversation-item ${conv.id === state.currentConversationId ? "active" : ""}`;
      item.dataset.id = conv.id;

      item.innerHTML = `
        <div class="conv-title-wrap">
          <span class="conv-bullet"></span>
          <span class="conv-title">${escapeHTML(conv.title)}</span>
        </div>
        <button class="conv-delete-btn" title="Delete conversation" aria-label="Delete conversation">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      `;

      item.addEventListener("click", () => {
        loadConversationMessages(conv.id);
        closeMobileSidebar();
      });

      const deleteBtn = item.querySelector(".conv-delete-btn");
      deleteBtn.addEventListener("click", (e) => deleteConversation(conv.id, e));

      conversationsList.appendChild(item);
    });
  }

  function appendMessageToUI(role, rawContent, options = {}) {
    const row = document.createElement("div");
    row.className = `message-row ${role}`;

    const formattedTime = formatTimestamp(options.createdAt);

    if (role === "user") {
      row.innerHTML = `
        <div class="message-content-wrap">
          <div class="message-bubble">${escapeHTML(rawContent)}</div>
          <div class="message-meta">
            <span>${formattedTime}</span>
          </div>
        </div>
        <div class="message-avatar user-avatar" title="You">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
        </div>
      `;
    } else {
      // Assistant Message
      let fallbackBadgeHTML = "";
      if (options.fallbackBadge) {
        let badgeClass = "";
        if (options.isEmergency) {
          badgeClass = "emergency";
        } else if (options.fallbackBadge === "Service Notice") {
          badgeClass = "notice";
        }
        fallbackBadgeHTML = `
          <div class="fallback-badge ${badgeClass}">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
              <polyline points="22 4 12 14.01 9 11.01"></polyline>
            </svg>
            <span>${escapeHTML(options.fallbackBadge)}</span>
          </div>
        `;
      }

      // Format markdown content
      const parsedBody = parseMarkdown(rawContent);

      // Emergency Callout Box
      let emergencyBoxHTML = "";
      if (options.isEmergency) {
        emergencyBoxHTML = `
          <div class="emergency-callout-card">
            <h4>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
              Immediate Medical Emergency Warning
            </h4>
            <p>Do not wait or rely on this chatbot for acute or life-threatening symptoms.</p>
            <div class="emergency-callout-actions">
              <a href="tel:${options.emergencyNumber || state.emergencyNumber}" class="emergency-call-btn-inline">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                Call Emergency (${options.emergencyNumber || state.emergencyNumber})
              </a>
            </div>
          </div>
        `;
      }

      // Verified Sources Section
      let sourcesHTML = "";
      if (options.sources && options.sources.length > 0) {
        const chips = options.sources.map(s => `
          <a href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer" class="source-chip" title="Open verified source in new tab">
            <span>${escapeHTML(s.title)}</span>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
          </a>
        `).join("");

        sourcesHTML = `
          <div class="message-sources-box">
            <div class="sources-header">Reliable Sources</div>
            <div class="sources-chips">${chips}</div>
          </div>
        `;
      }

      // Doctor Appointment Booking Card
      let bookingHTML = "";
      if (!options.isEmergency) {
        bookingHTML = `
          <div class="booking-handoff-card">
            <span class="booking-text">Need professional medical help?</span>
            <a href="${escapeHTML(options.bookingUrl || state.bookingUrl)}" target="_blank" rel="noopener noreferrer" class="booking-action-btn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="8.5" cy="7.5" r="4"></circle>
              </svg>
              Find a Doctor
            </a>
          </div>
        `;
      }

      row.innerHTML = `
        <div class="message-avatar assistant-avatar" title="Medicare Assistant">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
          </svg>
        </div>
        <div class="message-content-wrap">
          <div class="message-bubble">
            ${fallbackBadgeHTML}
            <div class="formatted-content">${parsedBody}</div>
            ${emergencyBoxHTML}
            ${sourcesHTML}
            ${bookingHTML}
          </div>
          <div class="message-meta">
            <span>${formattedTime}</span>
            <div class="message-actions">
              <button class="action-btn copy-btn" title="Copy response to clipboard">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                <span>Copy</span>
              </button>
              <button class="action-btn regen-btn" title="Regenerate this response">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="23 4 23 10 17 10"></polyline>
                  <polyline points="1 20 1 14 7 14"></polyline>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
                <span>Regenerate</span>
              </button>
            </div>
          </div>
        </div>
      `;

      // Copy response handler
      const copyBtn = row.querySelector(".copy-btn");
      if (copyBtn) {
        copyBtn.addEventListener("click", () => {
          navigator.clipboard.writeText(rawContent).then(() => {
            copyBtn.classList.add("copied");
            copyBtn.querySelector("span").textContent = "Copied!";
            setTimeout(() => {
              copyBtn.classList.remove("copied");
              copyBtn.querySelector("span").textContent = "Copy";
            }, 2000);
          }).catch(err => console.error("Could not copy:", err));
        });
      }

      // Regenerate handler
      const regenBtn = row.querySelector(".regen-btn");
      if (regenBtn) {
        regenBtn.addEventListener("click", () => {
          if (state.lastUserMessage) {
            sendMessage(state.lastUserMessage);
          }
        });
      }
    }

    messagesList.appendChild(row);
  }

  // ==========================================================================
  // Helper Utilities
  // ==========================================================================
  function parseMarkdown(text) {
    if (!text) return "";

    // 1. Sanitize to prevent XSS
    let escaped = escapeHTML(text);

    // 2. Bold text **text**
    escaped = escaped.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

    // 3. Headings: ### Header
    escaped = escaped.replace(/^###\s*(.*)$/gm, "<h3>$1</h3>");

    // 4. Bullet points: lines starting with • or - or *
    const lines = escaped.split("\n");
    let inList = false;
    let result = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const matchBullet = line.match(/^(\s*)(•|-|\*)\s+(.*)$/);

      if (matchBullet) {
        if (!inList) {
          result.push("<ul>");
          inList = true;
        }
        result.push(`<li>${matchBullet[3]}</li>`);
      } else {
        if (inList) {
          result.push("</ul>");
          inList = false;
        }
        // Wrap plain non-empty lines in paragraph if not an h3 tag
        if (line.trim().length > 0) {
          if (line.startsWith("<h3>")) {
            result.push(line);
          } else {
            result.push(`<p>${line}</p>`);
          }
        }
      }
    }

    if (inList) {
      result.push("</ul>");
    }

    return result.join("\n");
  }

  function escapeHTML(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function formatTimestamp(isoString) {
    const date = isoString ? new Date(isoString) : new Date();
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function showLoading(show) {
    if (typingIndicator) {
      typingIndicator.style.display = show ? "flex" : "none";
      if (show) scrollToBottom();
    }
  }

  function scrollToBottom() {
    setTimeout(() => {
      chatContainer.scrollTop = chatContainer.scrollHeight;
    }, 50);
  }

  function checkInputState() {
    const val = chatInput.value.trim();
    sendBtn.disabled = val.length === 0 || state.isGenerating;
  }

  function autoResizeTextarea() {
    chatInput.style.height = "auto";
    const newHeight = Math.min(chatInput.scrollHeight, 160);
    chatInput.style.height = `${newHeight}px`;
  }

  // ==========================================================================
  // Voice Input (Web Speech API)
  // ==========================================================================
  function setupVoiceInput() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      voiceBtn.title = "Voice recognition not supported in this browser";
      voiceBtn.style.opacity = "0.5";
      voiceBtn.addEventListener("click", () => {
        alert("Speech Recognition is not supported by your current browser. Please type your query.");
      });
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    let isListening = false;

    voiceBtn.addEventListener("click", () => {
      if (isListening) {
        recognition.stop();
        return;
      }
      try {
        recognition.start();
        isListening = true;
        voiceBtn.classList.add("listening");
        voiceBtn.title = "Listening... speak now";
      } catch (err) {
        console.error("Speech error:", err);
      }
    });

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      chatInput.value = transcript;
      checkInputState();
      autoResizeTextarea();
      sendMessage(transcript);
    };

    recognition.onerror = () => {
      isListening = false;
      voiceBtn.classList.remove("listening");
      voiceBtn.title = "Voice Input";
    };

    recognition.onend = () => {
      isListening = false;
      voiceBtn.classList.remove("listening");
      voiceBtn.title = "Voice Input";
    };
  }

  // ==========================================================================
  // Event Listeners
  // ==========================================================================
  function setupEventListeners() {
    // Send button
    sendBtn.addEventListener("click", () => sendMessage());

    // Enter & Shift+Enter handling
    chatInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });

    // Auto-resize textarea
    chatInput.addEventListener("input", () => {
      autoResizeTextarea();
      checkInputState();
    });

    // New Chat Button
    newChatBtn.addEventListener("click", startNewChat);

    // Clear Chat
    clearChatBtn.addEventListener("click", clearCurrentChat);

    // Suggested Questions Grid
    document.querySelectorAll(".suggestion-card").forEach(card => {
      card.addEventListener("click", () => {
        const prompt = card.dataset.prompt;
        if (prompt) {
          sendMessage(prompt);
        }
      });
    });

    // Mobile Sidebar Drawer
    if (openSidebarBtn) openSidebarBtn.addEventListener("click", openMobileSidebar);
    if (closeSidebarBtn) closeSidebarBtn.addEventListener("click", closeMobileSidebar);
    if (sidebarBackdrop) sidebarBackdrop.addEventListener("click", closeMobileSidebar);

    // Modals
    openResourcesBtn.addEventListener("click", openMedicalResourcesModal);
    openEmergencyBtn.addEventListener("click", () => openModal(emergencyModal));
    openAboutBtn.addEventListener("click", () => openModal(aboutModal));

    document.querySelectorAll(".close-modal-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const targetId = btn.dataset.close;
        if (targetId) {
          closeModal(document.getElementById(targetId));
        }
      });
    });

    document.querySelectorAll(".modal-overlay").forEach(overlay => {
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) {
          closeModal(overlay);
        }
      });
    });

    // Voice recognition
    setupVoiceInput();
  }

  function openMobileSidebar() {
    sidebar.classList.add("open");
    sidebarBackdrop.classList.add("open");
  }

  function closeMobileSidebar() {
    sidebar.classList.remove("open");
    sidebarBackdrop.classList.remove("open");
  }

  function openModal(modalEl) {
    if (modalEl) modalEl.classList.add("open");
  }

  function closeModal(modalEl) {
    if (modalEl) modalEl.classList.remove("open");
  }

  async function openMedicalResourcesModal() {
    openModal(resourcesModal);
    try {
      const res = await fetch("/api/sources");
      if (res.ok) {
        const data = await res.json();
        const sources = data.sources || [];
        sourcesContainer.innerHTML = sources.map(s => `
          <div class="resource-card">
            <div class="resource-card-top">
              <h5>${escapeHTML(s.title)}</h5>
              <span class="resource-cat-badge">${escapeHTML(s.category)}</span>
            </div>
            <a href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer" class="resource-link">
              Visit Official Portal
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                <polyline points="15 3 21 3 21 9"></polyline>
                <line x1="10" y1="14" x2="21" y2="3"></line>
              </svg>
            </a>
          </div>
        `).join("");
      }
    } catch (err) {
      sourcesContainer.innerHTML = '<div class="sidebar-empty">Unable to load sources.</div>';
    }
  }

  // Start app
  init();
});
