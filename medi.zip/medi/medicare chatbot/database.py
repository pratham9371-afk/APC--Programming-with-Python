"""
Database module for Medicare Assistant.
Handles SQLite connection, schema creation, message logging, and data retrieval.
"""

import os
import json
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_DIR = os.path.join(BASE_DIR, "database")
DB_PATH = os.path.join(DB_DIR, "medicare.db")
SOURCES_JSON_PATH = os.path.join(BASE_DIR, "data", "medical_sources.json")


def get_db_connection():
    """Returns a new connection to the SQLite database with Row factory enabled."""
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Initializes tables and seeds default medical sources if empty."""
    os.makedirs(DB_DIR, exist_ok=True)
    with get_db_connection() as conn:
        cursor = conn.cursor()

        # User accounts for login and registration
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # Conversations table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # Messages table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
            );
        """)

        # Medical Sources table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS medical_sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                category TEXT
            );
        """)

        # Seed sources if table is empty
        cursor.execute("SELECT COUNT(*) AS count FROM medical_sources")
        count = cursor.fetchone()["count"]
        if count == 0 and os.path.exists(SOURCES_JSON_PATH):
            try:
                with open(SOURCES_JSON_PATH, "r", encoding="utf-8") as f:
                    sources = json.load(f)
                    for s in sources:
                        cursor.execute(
                            "INSERT INTO medical_sources (title, url, category) VALUES (?, ?, ?)",
                            (s.get("title"), s.get("url"), s.get("category", "General"))
                        )
                conn.commit()
            except Exception as e:
                print(f"[Database] Warning: Could not seed medical sources: {e}")


def create_user(name: str, email: str, password_hash: str) -> int:
    """Creates a new user record and returns its ID."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
            (name.strip(), email.strip().lower(), password_hash)
        )
        conn.commit()
        return cursor.lastrowid


def get_user_by_email(email: str):
    """Retrieves a user by email address (case-insensitive)."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, name, email, password_hash, created_at FROM users WHERE LOWER(email) = LOWER(?)",
            (email.strip(),)
        )
        row = cursor.fetchone()
        return dict(row) if row else None


def get_user_by_id(user_id: int):
    """Retrieves a user by ID."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, name, email, password_hash, created_at FROM users WHERE id = ?",
            (user_id,)
        )
        row = cursor.fetchone()
        return dict(row) if row else None


def delete_user_by_email(email: str) -> bool:
    """Deletes a user account by email."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users WHERE LOWER(email) = LOWER(?)", (email.strip(),))
        conn.commit()
        return cursor.rowcount > 0


def create_conversation(title="New Consultation"):
    """Creates a new conversation record and returns its ID."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO conversations (title) VALUES (?)", (title,))
        conn.commit()
        return cursor.lastrowid


def get_all_conversations():
    """Returns all conversations ordered by creation date descending."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, title, created_at 
            FROM conversations 
            ORDER BY id DESC
        """)
        rows = cursor.fetchall()
        return [dict(row) for row in rows]


def get_conversation(conv_id):
    """Retrieves a single conversation by ID."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, created_at FROM conversations WHERE id = ?", (conv_id,))
        row = cursor.fetchone()
        return dict(row) if row else None


def update_conversation_title(conv_id, title):
    """Updates the title of a conversation."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE conversations SET title = ? WHERE id = ?", (title, conv_id))
        conn.commit()
        return cursor.rowcount > 0


def delete_conversation(conv_id):
    """Deletes a conversation and all associated messages."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM messages WHERE conversation_id = ?", (conv_id,))
        cursor.execute("DELETE FROM conversations WHERE id = ?", (conv_id,))
        conn.commit()
        return cursor.rowcount > 0


def add_message(conv_id, role, message):
    """Appends a message to a conversation."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO messages (conversation_id, role, message) VALUES (?, ?, ?)",
            (conv_id, role, message)
        )
        conn.commit()
        return cursor.lastrowid


def get_conversation_messages(conv_id):
    """Retrieves all messages for a given conversation ordered by created_at."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, conversation_id, role, message, created_at FROM messages WHERE conversation_id = ? ORDER BY id ASC",
            (conv_id,)
        )
        rows = cursor.fetchall()
        return [dict(row) for row in rows]


def clear_conversation_messages(conv_id):
    """Removes all messages from a conversation without deleting the conversation container."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM messages WHERE conversation_id = ?", (conv_id,))
        conn.commit()
        return True


def get_medical_sources(category=None):
    """Returns medical sources, optionally filtered by category."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if category:
            cursor.execute("SELECT id, title, url, category FROM medical_sources WHERE category = ?", (category,))
        else:
            cursor.execute("SELECT id, title, url, category FROM medical_sources ORDER BY id ASC")
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
