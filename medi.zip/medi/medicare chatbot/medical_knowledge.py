"""
Curated local medical knowledge base and emergency keyword detection.
Provides verified educational health information when external AI is offline or unavailable.
"""

import re

# Comprehensive emergency keywords and phrases
EMERGENCY_KEYWORDS = [
    "chest pain",
    "difficulty breathing",
    "can't breathe",
    "cannot breathe",
    "shortness of breath",
    "severe bleeding",
    "unconscious",
    "passed out",
    "fainting",
    "loss of consciousness",
    "stroke",
    "facial drooping",
    "arm weakness",
    "slurred speech",
    "seizure",
    "convulsion",
    "suicide",
    "kill myself",
    "ending my life",
    "overdose",
    "poison",
    "poisoning",
    "severe allergic reaction",
    "anaphylaxis",
    "heart attack",
    "coughing blood",
    "vomiting blood",
    "sudden numbness",
    "choking"
]

# Curated Medical Knowledge Base
MEDICAL_KNOWLEDGE = {
    "fever": {
        "title": "Fever (Elevated Body Temperature)",
        "keywords": ["fever", "high temperature", "chills", "febrile", "pyrexia", "hot and cold", "shivering", "temp"],
        "explanation": "A fever is a temporary increase in average body temperature (typically 100.4°F / 38°C or higher). It is generally part of the body's immune system fighting off an infection.",
        "causes": [
            "Viral infections such as the common cold, influenza (flu), or COVID-19",
            "Bacterial infections such as strep throat or urinary tract infections (UTIs)",
            "Heat exhaustion or severe sunburn",
            "Immunizations or side effects from specific medications"
        ],
        "symptoms": [
            "Sweating and shivering or chills",
            "Headache and generalized muscle aches",
            "Loss of appetite and lethargy",
            "Mild dehydration"
        ],
        "self_care": [
            "Drink plenty of fluids (water, clear broths, oral rehydration solutions) to prevent dehydration",
            "Get ample bed rest to allow your immune system to recover",
            "Dress in lightweight, breathable clothing and keep the room pleasantly cool",
            "Tepid sponge baths may provide physical comfort (avoid cold water or alcohol rubs)",
            "Over-the-counter antipyretics (e.g., paracetamol/acetaminophen) may be used strictly according to package instructions or doctor's advice"
        ],
        "warning_signs": [
            "Fever reaching 103°F (39.4°C) or higher in adults",
            "Fever lasting longer than 3 consecutive days without improvement",
            "Severe headache, stiff neck, or sensitivity to bright lights",
            "Difficulty breathing, chest tightness, or persistent vomiting",
            "Any fever in infants under 3 months of age (requires immediate medical evaluation)"
        ],
        "when_to_see_doctor": "Consult a healthcare professional if the fever persists for more than 72 hours, does not respond to medication, or is accompanied by confusion, rash, or intense pain.",
        "sources": [
            {"title": "CDC - Fever Facts & Guidance", "url": "https://www.cdc.gov"},
            {"title": "NHS - High Temperature (Fever) in Adults", "url": "https://www.nhs.uk/conditions/fever-in-adults/"},
            {"title": "MedlinePlus - Fever Overview", "url": "https://medlineplus.gov/fever.html"}
        ]
    },

    "headache": {
        "title": "Headache (Cephalea)",
        "keywords": ["headache", "migraine", "head pain", "throbbing head", "tension headache", "forehead pain"],
        "explanation": "Headaches are pain or discomfort in the head or face. Most headaches are primary headaches, such as tension headaches or migraines, and are not signs of a serious underlying condition.",
        "causes": [
            "Tension or muscle strain from stress, poor posture, or screen fatigue",
            "Dehydration or missed meals (low blood sugar)",
            "Lack of sleep or disrupted sleep schedule",
            "Caffeine withdrawal or excessive caffeine intake",
            "Sinus pressure from allergies or a cold"
        ],
        "symptoms": [
            "Dull, aching head pain or feeling like a tight band around the head (tension headache)",
            "Throbbing, pulsing pain often on one side (migraine)",
            "Tenderness in the scalp, neck, and shoulder muscles",
            "Sensitivity to light or sound"
        ],
        "self_care": [
            "Rest in a quiet, dark, and well-ventilated room",
            "Apply a warm or cool compress to your forehead or the back of your neck",
            "Drink a glass of water, especially if you have had low fluid intake",
            "Gently massage tense neck and temple muscles",
            "Take short screen breaks (follow the 20-20-20 rule)"
        ],
        "warning_signs": [
            "Sudden, extremely severe headache described as the 'worst headache of your life' (thunderclap headache)",
            "Headache accompanied by fever, stiff neck, confusion, or speech changes",
            "Headache following a head injury or physical trauma",
            "Numbness, weakness, or loss of vision on one side of the body"
        ],
        "when_to_see_doctor": "See a doctor if headaches become more frequent, wake you from sleep, fail to respond to standard pain relievers, or interfere with daily life.",
        "sources": [
            {"title": "NHS - Headaches Guide", "url": "https://www.nhs.uk/conditions/headaches/"},
            {"title": "MedlinePlus - Headache Types & Causes", "url": "https://medlineplus.gov/headache.html"},
            {"title": "Mayo Clinic - Headache Basics", "url": "https://www.mayoclinic.org"}
        ]
    },

    "cold": {
        "title": "Common Cold (Viral Upper Respiratory Infection)",
        "keywords": ["cold", "common cold", "runny nose", "sneezing", "stuffy nose", "nasal congestion"],
        "explanation": "The common cold is a harmless viral infection of the nose and throat (upper respiratory tract). Rhinoviruses are the most common culprit, and most people recover within 7 to 10 days.",
        "causes": [
            "Transmission of airborne viral droplets from coughing or sneezing",
            "Direct hand-to-hand contact with an infected individual or contaminated surface"
        ],
        "symptoms": [
            "Runny or stuffy nose",
            "Sneezing and mild tickling in the throat",
            "Low-grade fever or mild chills",
            "Mild body aches and fatigue"
        ],
        "self_care": [
            "Get plentiful sleep and rest your voice",
            "Stay hydrated with warm water, herbal teas, or clear broths",
            "Use saline nasal drops or sprays to alleviate nasal congestion",
            "Use a cool-mist humidifier in your room",
            "Gargle warm salt water (1/2 teaspoon salt in a glass of warm water) to soothe throat irritation"
        ],
        "warning_signs": [
            "Symptoms that worsen after 10 days or do not improve at all",
            "High fever, persistent earache, or sinus pain",
            "Difficulty breathing or persistent chest discomfort"
        ],
        "when_to_see_doctor": "Visit a clinic if cold symptoms persist beyond 10-14 days or if you experience severe shortness of breath or high fever.",
        "sources": [
            {"title": "CDC - Common Cold Guidelines", "url": "https://www.cdc.gov"},
            {"title": "NHS - Common Cold Advice", "url": "https://www.nhs.uk/conditions/common-cold/"},
            {"title": "MedlinePlus - Common Cold", "url": "https://medlineplus.gov/commoncold.html"}
        ]
    },

    "flu": {
        "title": "Influenza (Flu)",
        "keywords": ["flu", "influenza", "viral flu", "body aches flu", "chills fever flu"],
        "explanation": "Influenza is a contagious respiratory illness caused by influenza viruses. Unlike the common cold, flu symptoms typically arrive abruptly and are significantly more intense.",
        "causes": [
            "Infection with influenza A or B viruses spread via airborne respiratory droplets."
        ],
        "symptoms": [
            "Sudden onset of high fever and severe shaking chills",
            "Profound fatigue and generalized muscle weakness",
            "Dry, persistent cough",
            "Severe headache and sore throat"
        ],
        "self_care": [
            "Strict bed rest to support immune recovery",
            "High fluid intake (water, electrolyte solutions, warm teas)",
            "Isolation at home to prevent spreading to vulnerable family members",
            "Steam inhalation or a humidifier to loosen respiratory secretions"
        ],
        "warning_signs": [
            "Difficulty breathing or blueish lips/face",
            "Pain or pressure in the chest or abdomen",
            "Sudden dizziness, confusion, or inability to wake up",
            "Seizures or worsening of existing chronic conditions (e.g. asthma)"
        ],
        "when_to_see_doctor": "High-risk individuals (young children, pregnant women, elderly, immunocompromised) should contact a doctor promptly, as antiviral medications are most effective within 48 hours of symptom onset.",
        "sources": [
            {"title": "WHO - Influenza (Seasonal)", "url": "https://www.who.int/news-room/fact-sheets/detail/influenza-(seasonal)"},
            {"title": "CDC - Flu Information", "url": "https://www.cdc.gov/flu/"},
            {"title": "NHS - Flu Symptoms & Care", "url": "https://www.nhs.uk/conditions/flu/"}
        ]
    },

    "dehydration": {
        "title": "Dehydration",
        "keywords": ["dehydration", "dehydrated", "thirsty", "dry mouth", "dark urine", "lack of water", "hydrate"],
        "explanation": "Dehydration happens when your body loses more water and fluids than it takes in, impairing normal physiological functions and electrolyte balance.",
        "causes": [
            "Insufficient fluid intake during hot weather or strenuous physical activity",
            "Prolonged vomiting or severe diarrhea",
            "High fever causing increased fluid loss through sweat",
            "Excessive alcohol or caffeine consumption",
            "Diuretic medications"
        ],
        "symptoms": [
            "Extreme thirst and sticky, dry mouth",
            "Infrequent urination and dark amber-colored urine",
            "Dizziness, lightheadedness, or mild confusion",
            "Fatigue and sunken eyes"
        ],
        "self_care": [
            "Sip small amounts of water or Oral Rehydration Salts (ORS) solution continuously",
            "Eat hydrating foods with high water content (watermelon, cucumbers, oranges)",
            "Move to a cool, shaded environment and rest",
            "Avoid sugary sodas, energy drinks, and alcohol"
        ],
        "warning_signs": [
            "Inability to keep any fluids down for more than 12 hours",
            "No urination for 8 or more hours",
            "Extreme lethargy, confusion, fainting, or rapid heart rate",
            "Sunken fontanelle (soft spot) in infants"
        ],
        "when_to_see_doctor": "Severe dehydration requires prompt medical evaluation and potential intravenous (IV) fluid therapy at an urgent care or hospital clinic.",
        "sources": [
            {"title": "NHS - Dehydration Overview", "url": "https://www.nhs.uk/conditions/dehydration/"},
            {"title": "MedlinePlus - Dehydration Prevention", "url": "https://medlineplus.gov/dehydration.html"},
            {"title": "WHO - Oral Rehydration Salts Guidance", "url": "https://www.who.int"}
        ]
    },

    "diabetes": {
        "title": "Diabetes Mellitus (Overview)",
        "keywords": ["diabetes", "blood sugar", "glucose", "insulin", "diabetic", "high sugar", "type 2", "type 1"],
        "explanation": "Diabetes is a chronic metabolic condition characterized by elevated levels of blood glucose (blood sugar) due to either inadequate insulin production or the body's inability to effectively use insulin.",
        "causes": [
            "Type 1 Diabetes: Autoimmune reaction destroying insulin-producing beta cells in the pancreas",
            "Type 2 Diabetes: Insulin resistance linked to genetics, lifestyle factors, physical inactivity, and excess body weight",
            "Gestational Diabetes: Hormonal changes during pregnancy"
        ],
        "symptoms": [
            "Increased thirst (polydipsia) and frequent urination (polyuria), especially at night",
            "Unexplained weight loss despite normal or increased hunger",
            "Persistent fatigue and weakness",
            "Blurry vision and slow-healing cuts or sores",
            "Tingling or numbness in the hands or feet"
        ],
        "self_care": [
            "Adopt a balanced diet rich in whole grains, vegetables, and lean proteins; minimize refined sugars",
            "Engage in regular physical activity (such as 30 minutes of brisk walking daily)",
            "Monitor blood sugar levels as instructed by your healthcare physician",
            "Practice meticulous foot care and skin hygiene"
        ],
        "warning_signs": [
            "Fruity-smelling breath, nausea, vomiting, or confusion (signs of Diabetic Ketoacidosis - DKA)",
            "Extremely low blood sugar (hypoglycemia): shaking, sweating, confusion, dizziness (take fast-acting carbs like glucose tabs/juice)",
            "Non-healing ulcers or loss of sensation in the feet"
        ],
        "when_to_see_doctor": "If you notice persistent unexplained thirst, frequent urination, or unexplained weight loss, consult a doctor for a fasting blood sugar or HbA1c test.",
        "sources": [
            {"title": "WHO - Diabetes Factsheet", "url": "https://www.who.int/news-room/fact-sheets/detail/diabetes"},
            {"title": "CDC - Diabetes Basics", "url": "https://www.cdc.gov/diabetes/basics/index.html"},
            {"title": "NHS - Diabetes Overview", "url": "https://www.nhs.uk/conditions/diabetes/"}
        ]
    },

    "hypertension": {
        "title": "Hypertension (High Blood Pressure)",
        "keywords": ["hypertension", "high blood pressure", "bp", "blood pressure", "systolic", "diastolic"],
        "explanation": "Hypertension is a chronic medical condition where the long-term force of the blood against your artery walls is consistently high enough that it may eventually cause heart disease.",
        "causes": [
            "Primary hypertension: Develops gradually over many years due to genetics, age, and lifestyle",
            "High dietary sodium intake, lack of physical activity, and chronic stress",
            "Secondary causes: Kidney disease, thyroid disorders, or sleep apnea"
        ],
        "symptoms": [
            "Often referred to as the 'silent killer' because it usually has no obvious symptoms",
            "In rare severe spikes: Morning headaches, nosebleeds, vision changes, or dizziness"
        ],
        "self_care": [
            "Reduce dietary sodium (salt) and eat potassium-rich fruits and vegetables (DASH diet)",
            "Participate in regular aerobic exercise (150 minutes per week)",
            "Maintain a healthy weight and limit alcohol and tobacco consumption",
            "Practice stress-reduction techniques such as meditation or deep breathing"
        ],
        "warning_signs": [
            "Hypertensive crisis: Blood pressure over 180/120 mm Hg accompanied by chest pain, shortness of breath, back pain, or vision changes (emergency care required)"
        ],
        "when_to_see_doctor": "Have your blood pressure checked regularly during annual medical exams. If you have been diagnosed, take prescribed medications consistently.",
        "sources": [
            {"title": "WHO - Hypertension Guidelines", "url": "https://www.who.int/news-room/fact-sheets/detail/hypertension"},
            {"title": "CDC - High Blood Pressure", "url": "https://www.cdc.gov/bloodpressure/"},
            {"title": "MedlinePlus - High Blood Pressure", "url": "https://medlineplus.gov/highbloodpressure.html"}
        ]
    },

    "cough": {
        "title": "Cough (Acute and Chronic)",
        "keywords": ["cough", "coughing", "dry cough", "wet cough", "phlegm", "mucus cough", "hacking cough"],
        "explanation": "A cough is a natural reflex action that clears your airways of mucus, foreign irritants, and microbes.",
        "causes": [
            "Upper respiratory tract viral infections (colds, flu)",
            "Allergies, asthma, or environmental irritants (smoke, dust)",
            "Post-nasal drip from allergic rhinitis",
            "Gastroesophageal reflux disease (GERD / acid reflux)"
        ],
        "symptoms": [
            "Dry tickling cough or chesty cough producing clear or colored phlegm",
            "Throat irritation and hoarseness",
            "Mild chest tightness from repeated coughing spasms"
        ],
        "self_care": [
            "Honey (1 to 2 teaspoons) can soothe a dry cough (never give honey to infants under 1 year)",
            "Stay well hydrated with warm water, lemon water, or herbal tea",
            "Use a humidifier or inhale steam from a warm shower",
            "Elevate your head with an extra pillow when sleeping"
        ],
        "warning_signs": [
            "Coughing up blood or rust-colored phlegm",
            "Shortness of breath, wheezing, or stridor",
            "Cough lasting more than 3 to 4 weeks",
            "Unexplained weight loss or nighttime sweating"
        ],
        "when_to_see_doctor": "Consult a healthcare provider if your cough persists beyond 3 weeks, worsens at night, or causes severe chest discomfort.",
        "sources": [
            {"title": "NHS - Cough Guidance", "url": "https://www.nhs.uk/conditions/cough/"},
            {"title": "MedlinePlus - Cough Causes & Treatments", "url": "https://medlineplus.gov/cough.html"}
        ]
    },

    "sore_throat": {
        "title": "Sore Throat (Pharyngitis)",
        "keywords": ["sore throat", "throat pain", "pain swallowing", "scratchy throat", "strep", "tonsillitis"],
        "explanation": "A sore throat is pain, scratchiness, or irritation of the throat that often worsens when you swallow. The vast majority of sore throats are caused by viral infections.",
        "causes": [
            "Viral infections such as common cold, flu, or mononucleosis",
            "Bacterial infections such as Streptococcus pyogenes (Strep throat)",
            "Dry indoor air, vocal strain, or allergies"
        ],
        "symptoms": [
            "Pain or a scratchy sensation in the throat",
            "Difficulty or pain while swallowing food or liquids",
            "Red, swollen tonsils, sometimes with white patches or pus",
            "Swollen, tender lymph nodes in the neck"
        ],
        "self_care": [
            "Gargle several times a day with warm salt water (1/2 teaspoon of salt in warm water)",
            "Drink soothing warm liquids like decaf tea with honey or clear broths",
            "Suck on throat lozenges or hard candies to stimulate saliva production",
            "Rest your voice and avoid cigarette smoke or irritants"
        ],
        "warning_signs": [
            "Inability to swallow your own saliva or fluids (drooling)",
            "Difficulty breathing or a high-pitched sound while inhaling",
            "High fever accompanied by rash or severe joint pain",
            "Sore throat lasting longer than 7 days"
        ],
        "when_to_see_doctor": "If you suspect strep throat (severe throat pain without cold symptoms, accompanied by fever and swollen neck glands), a doctor can perform a rapid swab and prescribe antibiotics if appropriate.",
        "sources": [
            {"title": "CDC - Sore Throat & Strep Guidance", "url": "https://www.cdc.gov/groupastrep/diseases-public/strep-throat.html"},
            {"title": "NHS - Sore Throat Advice", "url": "https://www.nhs.uk/conditions/sore-throat/"}
        ]
    },

    "stomach_pain": {
        "title": "Stomach & Abdominal Discomfort",
        "keywords": ["stomach pain", "stomach ache", "belly pain", "abdominal pain", "indigestion", "cramps", "upset stomach", "gastritis"],
        "explanation": "Stomach or abdominal pain is discomfort felt anywhere between the chest and groin. Most cases are mild and resolve quickly on their own.",
        "causes": [
            "Indigestion, gas, or overeating spicy/greasy foods",
            "Gastroenteritis (stomach flu) or foodborne illness",
            "Constipation or irritable bowel syndrome (IBS)",
            "Menstrual cramps or mild stress-related tension"
        ],
        "symptoms": [
            "Bloating, gas, and rumbling in the abdomen",
            "Cramping sensations that come and go",
            "Mild nausea or loss of appetite"
        ],
        "self_care": [
            "Sip clear fluids such as water, ginger tea, or peppermint tea",
            "Eat small, bland meals (the BRAT diet: bananas, rice, applesauce, toast)",
            "Apply a warm heating pad to your abdomen to soothe muscular cramps",
            "Avoid NSAID pain relievers (like ibuprofen) if you have stomach irritation, as they can irritate stomach lining"
        ],
        "warning_signs": [
            "Sudden, severe, sharp pain, especially localized in the lower right abdomen (potential appendicitis)",
            "Vomiting blood or black, tarry bowel movements",
            "Abdomen is rigid, hard, and extremely tender to the touch",
            "Pain accompanied by high fever or yellowing of skin/eyes (jaundice)"
        ],
        "when_to_see_doctor": "Seek emergency medical evaluation for severe, escalating, or localized abdominal pain, or if pain is accompanied by fever, persistent vomiting, or inability to pass gas.",
        "sources": [
            {"title": "NHS - Stomach Ache & Abdominal Pain", "url": "https://www.nhs.uk/conditions/stomach-ache/"},
            {"title": "MedlinePlus - Abdominal Pain", "url": "https://medlineplus.gov/abdominalpain.html"}
        ]
    },

    "first_aid": {
        "title": "Basic First Aid (Minor Cuts, Burns, and Sprains)",
        "keywords": ["first aid", "cut", "burn", "sprain", "minor injury", "scrape", "wound", "twisted ankle"],
        "explanation": "Basic first aid involves the initial, immediate assistance given to someone suffering a minor illness or injury before professional medical care can be obtained.",
        "causes": [
            "Everyday household accidents, kitchen cuts, minor scalds, or athletic ankle sprains"
        ],
        "symptoms": [
            "Minor localized bleeding or abrasions",
            "Mild redness, pain, and minor swelling"
        ],
        "self_care": [
            "Minor Cuts & Scrapes: Wash hands, apply gentle pressure with a clean cloth to stop bleeding, rinse gently with cool clean water, apply petroleum jelly or antibiotic ointment, and cover with a sterile bandage.",
            "Minor Burns (1st Degree): Hold the burn under cool running water for 10-15 minutes (never use ice). Apply pure aloe vera gel and keep covered loosely with a sterile bandage.",
            "Sprains & Strains (R.I.C.E. protocol): Rest the injured limb; Ice with a towel-wrapped cold pack for 15-20 min; Compress with an elastic bandage; Elevate above heart level."
        ],
        "warning_signs": [
            "Bleeding that will not stop after 10 minutes of direct, continuous pressure",
            "Deep, gaping wounds exposing fat, muscle, or bone (stitches needed)",
            "Signs of infection: spreading redness, red streaks, warmth, or yellow pus",
            "Inability to bear any weight on an injured joint"
        ],
        "when_to_see_doctor": "Visit an urgent care center for deep wounds, puncture wounds, animal bites, electrical burns, or injuries that may require a tetanus booster.",
        "sources": [
            {"title": "CDC - First Aid & Safety Guidance", "url": "https://www.cdc.gov"},
            {"title": "NHS - First Aid Overview", "url": "https://www.nhs.uk/conditions/first-aid/"},
            {"title": "Mayo Clinic - First Aid Basics", "url": "https://www.mayoclinic.org"}
        ]
    },

    "when_to_see_doctor": {
        "title": "When to Seek Professional Medical Care",
        "keywords": ["when should i see a doctor", "when to see a doctor", "see a doctor", "doctor visit", "consult a doctor", "medical checkup"],
        "explanation": "Knowing when to transition from home self-care to professional medical evaluation is vital for your health and peace of mind.",
        "causes": [
            "Persistent symptoms, worsening trajectory, or presence of 'red flag' clinical signs."
        ],
        "symptoms": [
            "Any symptoms that disrupt sleep, daily routines, or work for more than several days",
            "Unexplained weight loss, changes in bowel/bladder habits, or non-healing sores"
        ],
        "self_care": [
            "Maintain a symptom journal noting when symptoms began, frequency, and severity",
            "Keep an updated list of your current medications, vitamins, and allergies",
            "Prepare a list of specific questions to ask your physician during your visit"
        ],
        "warning_signs": [
            "Red Flag Signs requiring Urgent or Emergency Care:",
            "• Severe chest pressure, radiating arm/jaw pain",
            "• Sudden weakness, speech difficulty, or facial droop",
            "• Severe shortness of breath or sudden respiratory distress",
            "• High, uncontrolled fever unresponsive to medication"
        ],
        "when_to_see_doctor": "Schedule a routine or urgent doctor appointment whenever symptoms persist longer than expected (e.g. cold >10 days, fever >3 days, cough >3 weeks) or whenever you feel uncertain about your condition.",
        "sources": [
            {"title": "NHS - How to Get Medical Help", "url": "https://www.nhs.uk"},
            {"title": "CDC - Patient Healthcare Guidance", "url": "https://www.cdc.gov"},
            {"title": "MedlinePlus - Talking With Your Doctor", "url": "https://medlineplus.gov/talkingwithyourdoctor.html"}
        ]
    },

    "dengue": {
        "title": "Dengue Fever",
        "keywords": ["dengue", "dengue fever", "breakbone", "platelets", "aedes", "mosquito bite fever"],
        "explanation": "Dengue is a viral infection transmitted to humans through the bites of infected Aedes mosquitoes. While most cases are mild, it can occasionally progress to severe dengue.",
        "causes": [
            "Infection with any of four dengue virus serotypes (DENV-1, DENV-2, DENV-3, DENV-4)",
            "Transmission primarily via bites from female Aedes aegypti and Aedes albopictus mosquitoes"
        ],
        "symptoms": [
            "Sudden high fever (often reaching 104°F / 40°C)",
            "Severe headache and pain behind the eyes (retro-orbital pain)",
            "Severe joint, bone, and muscle pains (often called 'breakbone fever')",
            "Nausea, vomiting, and loss of appetite",
            "Fine skin rash appearing a few days after fever onset"
        ],
        "self_care": [
            "Get strict bed rest to help your body combat the infection",
            "Maintain high fluid intake (oral rehydration salts, coconut water, clean broths, water) to avoid dehydration",
            "Use paracetamol strictly as guided for fever and pain relief",
            "AVOID non-steroidal anti-inflammatory drugs (NSAIDs) such as ibuprofen, aspirin, or naproxen, as they can significantly increase bleeding risks in dengue"
        ],
        "warning_signs": [
            "Severe, relentless abdominal pain or continuous vomiting",
            "Bleeding from the gums, nose, or blood in vomit/stool",
            "Rapid breathing, extreme fatigue, drowsiness, or restlessness",
            "Sudden drop in body temperature accompanied by clammy skin"
        ],
        "when_to_see_doctor": "Consult a healthcare provider immediately if you experience high fever with joint pain in an area with known dengue activity. A simple complete blood count (CBC) test can monitor your platelet count.",
        "sources": [
            {"title": "WHO - Dengue Fact Sheet", "url": "https://www.who.int/news-room/fact-sheets/detail/dengue-and-severe-dengue"},
            {"title": "CDC - Dengue Guidance", "url": "https://www.cdc.gov/dengue/"}
        ]
    }
}


def check_emergency(text: str):
    """
    Scans the given user text for critical emergency keywords.
    Returns (is_emergency: bool, warning_details: str).
    """
    if not text:
        return False, ""

    clean_text = text.lower()
    for kw in EMERGENCY_KEYWORDS:
        # Match whole words or clean boundaries
        pattern = r"\b" + re.escape(kw) + r"\b"
        if re.search(pattern, clean_text):
            return True, kw

    return False, ""


def find_medical_topic(query: str):
    """
    Searches the curated medical knowledge base for the best matching topic.
    Returns the topic dictionary or None if no confident match.
    """
    if not query:
        return None

    query_lower = query.lower()
    words = set(re.findall(r"\w+", query_lower))

    best_topic = None
    best_score = 0

    for key, data in MEDICAL_KNOWLEDGE.items():
        score = 0
        
        # Check topic key match
        if key in query_lower:
            score += 5

        # Check keywords
        for kw in data["keywords"]:
            kw_lower = kw.lower()
            if kw_lower in query_lower:
                score += 4
            else:
                kw_words = set(kw_lower.split())
                overlap = len(words.intersection(kw_words))
                if overlap > 0:
                    score += overlap * 2

        if score > best_score:
            best_score = score
            best_topic = data

    # Threshold for match
    if best_score >= 3:
        return best_topic

    return None
