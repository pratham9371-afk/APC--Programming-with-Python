"""
Flask Web Application for Medicare Assistant.
Exposes clean RESTful API endpoints and serves the modern healthcare chatbot frontend.
"""

import os
import re
from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

import database as db
import ai_service

# Load environment configuration
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY") or os.getenv("SECRET_KEY", "medicare-assistant-secret-key-change-in-production")
app.config["JSON_SORT_KEYS"] = False

# Maximum message character limit to prevent abuse / payload bloating
MAX_MESSAGE_LENGTH = 2000

# Initialize database schema and default sources
db.init_db()


def generate_title_from_prompt(prompt: str) -> str:
    """Generates a clean, short title for the conversation based on the first question."""
    cleaned = prompt.strip()
    
    # Check if prompt is a greeting or conversational phrase
    is_conv, _ = ai_service.check_conversational_phrase(cleaned)
    if is_conv:
        return "General Consultation"

    # Strip common question prefixes
    for prefix in [
        r"^what\s+(is|are)\s+(the\s+)?(symptoms\s+of\s+)?",
        r"^tell\s+me\s+about\s+",
        r"^how\s+(to|can\s+i)\s+",
        r"^when\s+should\s+i\s+",
        r"^what\s+causes\s+",
        r"^can\s+you\s+explain\s+"
    ]:
        cleaned = re.sub(prefix, "", cleaned, flags=re.IGNORECASE)

    cleaned = re.sub(r"[?!.,;:]+$", "", cleaned).strip()
    if not cleaned:
        cleaned = prompt[:30].strip()

    # Capitalize nicely
    title = cleaned[:35].strip()
    return title.title() if len(title) > 0 else "Health Query"


@app.route("/")
def index():
    """Serves the primary Medicare Assistant web interface."""
    if "user_id" not in session:
        return redirect(url_for("login", next=request.path))
    return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Handles user authentication."""
    if "user_id" in session:
        return redirect(url_for("index"))

    next_url = request.args.get("next") or request.form.get("next") or url_for("index")

    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""

        if not email or not password:
            flash("Please enter both email and password.", "error")
            return render_template("login.html"), 400

        user = db.get_user_by_email(email)
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Invalid email or password. Please try again.", "error")
            return render_template("login.html"), 401

        session["user_id"] = user["id"]
        session["user_name"] = user["name"]
        session["user_email"] = user["email"]

        if not next_url.startswith("/") or next_url.startswith("//"):
            next_url = url_for("index")

        return redirect(next_url)

    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Handles new user account registration."""
    if "user_id" in session:
        return redirect(url_for("index"))

    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        confirm_password = request.form.get("confirm_password") or ""

        if not name:
            flash("Please enter your name.", "error")
            return render_template("register.html"), 400

        if not email or "@" not in email:
            flash("Please enter a valid email address.", "error")
            return render_template("register.html"), 400

        if len(password) < 8:
            flash("Password must be at least 8 characters long.", "error")
            return render_template("register.html"), 400

        if password != confirm_password:
            flash("Passwords do not match. Please re-enter.", "error")
            return render_template("register.html"), 400

        existing = db.get_user_by_email(email)
        if existing:
            flash("An account with this email already exists. Please log in.", "error")
            return render_template("register.html"), 400

        password_hash = generate_password_hash(password)
        try:
            user_id = db.create_user(name=name, email=email, password_hash=password_hash)
            session["user_id"] = user_id
            session["user_name"] = name
            session["user_email"] = email
            return redirect(url_for("index"))
        except Exception as e:
            print(f"[Error] register: {e}")
            flash("An error occurred during registration. Please try again.", "error")
            return render_template("register.html"), 500

    return render_template("register.html")


@app.route("/logout", methods=["GET", "POST"])
def logout():
    """Logs out the current user by clearing the session."""
    session.clear()
    flash("You have been logged out successfully.", "info")
    return redirect(url_for("login"))


@app.route("/api/health", methods=["GET"])
def health_check():
    """System health check endpoint."""
    return jsonify({
        "status": "ok",
        "service": "Medicare Assistant",
        "database": "sqlite_ready",
        "ai_fallback_available": True
    }), 200


@app.route("/api/config", methods=["GET"])
def get_config():
    """Provides non-sensitive configuration parameters to the frontend."""
    return jsonify({
        "emergency_number": os.getenv("EMERGENCY_NUMBER", "112"),
        "booking_url": os.getenv("BOOKING_URL", "https://www.practo.com")
    }), 200


@app.route("/api/conversations", methods=["GET"])
def get_conversations():
    """Retrieves all past conversations."""
    try:
        conversations = db.get_all_conversations()
        return jsonify({"conversations": conversations}), 200
    except Exception as e:
        print(f"[Error] get_conversations: {e}")
        return jsonify({"error": "Failed to retrieve conversations."}), 500


@app.route("/api/conversations", methods=["POST"])
def create_conversation():
    """Creates a new conversation container."""
    try:
        data = request.get_json(silent=True) or {}
        title = data.get("title", "New Consultation").strip()
        conv_id = db.create_conversation(title=title)
        return jsonify({
            "id": conv_id,
            "title": title,
            "status": "created"
        }), 201
    except Exception as e:
        print(f"[Error] create_conversation: {e}")
        return jsonify({"error": "Failed to create conversation."}), 500


@app.route("/api/conversations/<int:conv_id>/messages", methods=["GET"])
def get_messages(conv_id):
    """Retrieves all messages for a specific conversation."""
    try:
        conversation = db.get_conversation(conv_id)
        if not conversation:
            return jsonify({"error": "Conversation not found."}), 404

        messages = db.get_conversation_messages(conv_id)
        return jsonify({
            "conversation": conversation,
            "messages": messages
        }), 200
    except Exception as e:
        print(f"[Error] get_messages: {e}")
        return jsonify({"error": "Failed to retrieve messages."}), 500


@app.route("/api/chat", methods=["POST"])
def chat():
    """
    Primary chat endpoint.
    Expects JSON: { "conversation_id": optional_int, "message": str }
    """
    try:
        data = request.get_json(silent=True)
        if not data or "message" not in data:
            return jsonify({"error": "Missing 'message' in request body."}), 400

        user_message = data["message"].strip()
        if not user_message:
            return jsonify({"error": "Message cannot be empty."}), 400

        if len(user_message) > MAX_MESSAGE_LENGTH:
            return jsonify({
                "error": f"Message exceeds maximum permitted length of {MAX_MESSAGE_LENGTH} characters."
            }), 400

        conv_id = data.get("conversation_id")

        # Create new conversation if none provided or invalid
        if not conv_id:
            title = generate_title_from_prompt(user_message)
            conv_id = db.create_conversation(title=title)
        else:
            conv = db.get_conversation(conv_id)
            if not conv:
                title = generate_title_from_prompt(user_message)
                conv_id = db.create_conversation(title=title)
            elif conv["title"] in ("General Consultation", "New Consultation", "New Chat"):
                # If current title is generic and this message is a medical question, update title
                is_conv, _ = ai_service.check_conversational_phrase(user_message)
                if not is_conv:
                    new_title = generate_title_from_prompt(user_message)
                    db.update_conversation_title(conv_id, new_title)

        # Get existing history for context
        history = db.get_conversation_messages(conv_id)

        # Save user message to database
        db.add_message(conv_id=conv_id, role="user", message=user_message)

        # Generate response via AI Service (with automatic local fallback)
        ai_result = ai_service.generate_response(user_message, history)

        reply_text = ai_result.get("reply", "")

        # Save assistant message to database
        db.add_message(conv_id=conv_id, role="assistant", message=reply_text)

        # Retrieve updated conversation record
        conv = db.get_conversation(conv_id)

        return jsonify({
            "conversation_id": conv_id,
            "conversation_title": conv["title"] if conv else "Chat",
            "reply": reply_text,
            "sources": ai_result.get("sources", []),
            "is_emergency": ai_result.get("is_emergency", False),
            "is_fallback": ai_result.get("is_fallback", False),
            "fallback_badge": ai_result.get("fallback_badge"),
            "emergency_number": ai_result.get("emergency_number", "112"),
            "booking_url": ai_result.get("booking_url", "https://www.practo.com")
        }), 200

    except Exception as e:
        print(f"[Error] /api/chat exception: {e}")
        return jsonify({
            "error": "Something went wrong. Please try again.",
            "reply": "I apologize, but an unexpected error occurred while processing your request. Please try asking again.",
            "sources": []
        }), 500


@app.route("/api/conversations/<int:conv_id>", methods=["DELETE"])
def delete_conversation(conv_id):
    """Deletes a conversation and its messages."""
    try:
        success = db.delete_conversation(conv_id)
        if not success:
            return jsonify({"error": "Conversation not found or already deleted."}), 404
        return jsonify({"status": "deleted", "id": conv_id}), 200
    except Exception as e:
        print(f"[Error] delete_conversation: {e}")
        return jsonify({"error": "Failed to delete conversation."}), 500


@app.route("/api/conversations/<int:conv_id>/clear", methods=["POST"])
def clear_conversation(conv_id):
    """Clears all messages in an existing conversation."""
    try:
        db.clear_conversation_messages(conv_id)
        return jsonify({"status": "cleared", "id": conv_id}), 200
    except Exception as e:
        print(f"[Error] clear_conversation: {e}")
        return jsonify({"error": "Failed to clear conversation."}), 500


@app.route("/api/sources", methods=["GET"])
def get_sources():
    """Retrieves verified medical sources from the database."""
    try:
        sources = db.get_medical_sources()
        return jsonify({"sources": sources}), 200
    except Exception as e:
        print(f"[Error] get_sources: {e}")
        return jsonify({"error": "Failed to retrieve sources."}), 500


# Safe Error Handlers
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found."}), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error. Please try again."}), 500


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "True").lower() in ("true", "1", "t")
    print("==================================================")
    print(f" Medicare Assistant starting on http://127.0.0.1:{port}")
    print(f" Emergency Number Configured: {os.getenv('EMERGENCY_NUMBER', '112')}")
    if ai_service.is_api_configured():
        print(f" AI API Status: Configured (Model: {os.getenv('AI_MODEL', 'gpt-3.5-turbo')})")
    else:
        print(" WARNING: AI API is not configured.")
        print(" Using local fallback mode.")
    print("==================================================")
    app.run(host="127.0.0.1", port=port, debug=debug)
